from columnsAdjuster import columnAdjuster



data = columnAdjuster('text.xlsx')
print(data)
