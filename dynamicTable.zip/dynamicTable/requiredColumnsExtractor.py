
# ['Header', [keys], [['columnName', 'column key-1', 'column key-1',]]]
# ['Gross merchandise volume', ['Gross merchandise volume'], [['Three-1','three']]]
def requiredColumns(table, requiredData):
    filterData = []
    for row in table:
        name = row['Name_']

        for rd in requiredData:
            for key in rd[1]:
                if not isinstance(name, str):
                    continue
                if key in name:
                    for head in rd[2]:

                        for r in row.items():
                            foundHead = 0

                            for h in head:
                               if h.lower() in r[0].lower():
                                   foundHead+=1

                            if len(head)-1 == foundHead:

                                filterData.append([row['Name_'], head[0], r[0], r[1]])

    return filterData