
def checkKey(text, keys):
    text = text.lower()
    # print(keys)
    combination = []
    tableFoundKeys = []
    for id, key in enumerate(keys):
        # print(key)
        key = [k.lower() for k in key.values() if isinstance(k, str)]
        # print(key)
        count = 0
        for k in key:
            # print(k)
            if k in text:
                count+=1
        if len(key) == count:
            tableFoundKeys.append([id, True, key])
    return tableFoundKeys