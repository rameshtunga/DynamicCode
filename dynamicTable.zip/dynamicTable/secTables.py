import requests
from bs4 import BeautifulSoup
import pandas as pd
from tableDataExtractor import tableDataExtractor
from columnsAdjuster import columnAdjuster
keys = pd.read_excel('keywords.xlsx')
keys = keys.to_dict('records')
def checkKey(text):
    text = text.lower()
    # print(keys)
    combination = []
    tableFoundKeys = []
    for id, key in enumerate(keys):
        # print(key)
        key = [k.lower() for k in key.values() if isinstance(k, str)]
        # print(key)
        count = 0
        for k in key:
            # print(k)
            if k in text:
                count+=1
        if len(key) == count:
            tableFoundKeys.append([id, True, key])
    return tableFoundKeys

# data = """
# ﻿  Other Data  ﻿  ﻿  ﻿  ﻿                                   ﻿      Nine-months Periods Ended  September 30,    Three-month Periods Ended  September 30,  (in millions)       2018   2017 (11)    2018  2017 (11)  ﻿                      Number of confirmed registered users at end of period (1)       248.9 	  201.2 	      248.9 	      201.2  Number of confirmed new registered users during period (2)       36.7 	  27.0 	      14.0 	      10.0  Gross merchandise volume (3)      $  9,271.8 	 $  8,131.6 	     $  2,995.2 	     $  3,075.3  Number of successful items sold (4)       249.1 	  188.9 	      83.5 	      74.2  Number of successful items shipped (5)    159.6 	  102.4 	   54.3 	   41.7  Total payment volume (6)      $  13,153.8 	 $  9,388.9 	     $  4,552.4 	     $  3,667.1  Total volume of payments on marketplace (7)      $  8,324.1 	 $  6,620.3 	     $  2,720.3 	     $  2,592.9  Total payment transactions (8)    263.7 	  158.2 	   103.9 	   62.3  Unique buyers (9)    33.1 	  27.6 	   17.9 	   16.3  Unique sellers (10)    12.9 	  8.7 	   4.3 	   4.6  Capital expenditures $  72.1 	 $  52.1 	     $  25.3 	     $  17.5  Depreciation and amortization      $  33.9 	 $  30.0 	     $  11.3 	     $  10.9
# """

# found = checkKey(data)
# print('found it  = ', found)

resp = requests.get('https://www.sec.gov/Archives/edgar/data/1099590/000156276218000323/meli-20180930x10q.htm')

jsoup = BeautifulSoup(resp.content)

tables = jsoup.find_all('table')
print('Length of Tables = ', len(tables))

for table in tables:
    tableCheck = checkKey(table.text)
    if len(tableCheck)!=0:
        if len(tableCheck) == 1:
            table = tableDataExtractor(table)
            print(table)
            df = pd.DataFrame(table, columns=None)
            df.to_excel('test.xlsx', index=False)
            data = columnAdjuster(fileName = 'test.xlsx')
            print(data)
        print('===========================================================================')

