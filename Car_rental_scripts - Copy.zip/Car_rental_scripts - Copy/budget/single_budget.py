from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import pandas as pd
import time
import re
from datetime import datetime
from datetime import timedelta
from bs4 import BeautifulSoup

driver = webdriver.Firefox()
file = ['ATL', 'ORD', 'LAX', 'DFW', 'JFK', 'DEN', 'SFO', 'LAS', 'CLT', 'MIA', 'PHX', 'SEA', 'MCO', 'EWR', 'MSP', 'BOS',
        'DTW', 'PHL', 'LGA', 'FLL', 'BWI', 'DCA', 'MDW', 'SLC', 'IAD', 'SAN', 'HNL', 'TPA', 'PDX', 'IAH']
headers = ["Date", "pickup_date", "return_date", "Location", "Airport name", "selected_location",
             "Location Code", "className", "vehicleName", 'payLaterAmount',  'Pay_Now_Amount', "Sold_Out", "sitename"]
def get_budget_data():
    check_days = [[15, 17], [15, 22]]
    for k in check_days:
        start_date = (datetime.now() + timedelta(days=k[0])).strftime('%m/%d/%Y')
        end_date = (datetime.now() + timedelta(days=k[1])).strftime('%m/%d/%Y')
        driver.get('https://www.budget.com/en/home')
        driver.find_element_by_xpath('//*[@id="PicLoc_value"]').clear()
        h_val = driver.find_element_by_xpath('//*[@id="PicLoc_value"]')
        h_val.send_keys(i)
        wait = WebDriverWait(driver, 10)
        wait.until(EC.visibility_of_element_located(
            (By.XPATH, '//*[@id="PicLoc_dropdown"]/div[3]/div[1]/div[2]/div/div/span/span[1]')))
        driver.find_element_by_xpath('//*[@id="PicLoc_dropdown"]/div[3]/div[1]/div[2]/div/div/span/span[1]').click()
        print(h_val.get_attribute('value'))
        l_se = h_val.get_attribute('value')
        driver.find_element_by_xpath('//*[@id="from"]').clear()
        driver.find_element_by_xpath('//*[@id="to"]').clear()
        date_pick_start = driver.find_element_by_xpath('//*[@id="from"]').send_keys(start_date)
        date_pick_end = driver.find_element_by_xpath('//*[@id="to"]').send_keys(end_date)
        wait = WebDriverWait(driver, 10)
        wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="to"]')))
        driver.find_element_by_xpath('//*[@id="to"]').send_keys(Keys.RETURN)
        wait = WebDriverWait(driver, 10)
        wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="res-home-select-car"]')))
        driver.find_element_by_xpath('//*[@id="res-home-select-car"]').click()
        try:
            time.sleep(10)
            try:
                wait = WebDriverWait(driver, 10)
                wait.until(EC.visibility_of_element_located((By.CLASS_NAME, "vehicle-availability")))
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(5)
                cars = BeautifulSoup(driver.page_source).find_all('div', attrs={'class': 'row avilablecar available-car-box'})
                print(len(cars))
                for car in cars:
                    try:
                        className = car.find('h3').text
                        vehicleName = car.find('p', attrs={'class': re.compile('featurecartxt')})
                        vehicleName = vehicleName.text if vehicleName is not None else None
                        Pay_Now_Amount = car.find('div', attrs={'class': re.compile('paynow')})
                        Pay_Now_Amount = (Pay_Now_Amount.find('p').text if Pay_Now_Amount.find('p') is not None else None)if Pay_Now_Amount is not None else None
                        payLaterAmount = car.find('div', attrs={'class': re.compile('payatcntr')})
                        payLaterAmount = (payLaterAmount.find('p').text if payLaterAmount.find('p') is not None else None) if payLaterAmount is not None else None
                        data = [datetime.today().strftime('%d/%m/%Y'), start_date, end_date, "Location", "Airport name", "selected_location",
                         "Location Code", className, vehicleName, payLaterAmount, Pay_Now_Amount, "Sold_Out",
                         "sitename"]
                        print(data)
                    except Exception as e:
                        print(e)
            except:
                print('passs')

        except:
            print('sold out')

            break
            # import sys
            # sys.exit(1)
        # driver.delete_all_cookies()
        break
    # driver.close()
