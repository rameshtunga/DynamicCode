from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time
import re
import os
from datetime import datetime
from datetime import timedelta
from bs4 import BeautifulSoup


def get_budget_car_data(row, car_data):
    dir = os.getcwd() + '\\' + datetime.today().strftime('%d-%m-%Y')
    if not os.path.isdir(dir):
        os.mkdir(dir)
    driver = webdriver.Firefox()
    driver.maximize_window()
    carData = []
    count = 0
    check_count = 0

    check_days = [[15, 17], [15, 22]]
    for k in check_days:
        try:
            start_date = (datetime.now() + timedelta(days=k[0])).strftime('%m/%d/%Y')
            end_date = (datetime.now() + timedelta(days=k[1])).strftime('%m/%d/%Y')
            driver.get('https://www.budget.com/en/home')
            driver.find_element_by_xpath('//*[@id="PicLoc_value"]').clear()
            h_val = driver.find_element_by_xpath('//*[@id="PicLoc_value"]')
            h_val.send_keys(row['Code'])
            wait = WebDriverWait(driver, 10)
            wait.until(EC.visibility_of_element_located(
                (By.XPATH, '//*[@id="PicLoc_dropdown"]/div[3]/div[1]/div[2]/div/div/span/span[1]')))
            driver.find_element_by_xpath('//*[@id="PicLoc_dropdown"]/div[3]/div[1]/div[2]/div/div/span/span[1]').click()
            print(h_val.get_attribute('value'))
            l_se = h_val.get_attribute('value')
            driver.find_element_by_xpath('//*[@id="from"]').clear()
            driver.find_element_by_xpath('//*[@id="to"]').clear()
            driver.find_element_by_xpath('//*[@id="from"]').send_keys(start_date)
            driver.find_element_by_xpath('//*[@id="to"]').send_keys(end_date)
            wait = WebDriverWait(driver, 10)
            wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="to"]')))
            driver.find_element_by_xpath('//*[@id="to"]').send_keys(Keys.RETURN)
            wait = WebDriverWait(driver, 10)
            wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="res-home-select-car"]')))
            driver.find_element_by_xpath('//*[@id="res-home-select-car"]').click()
            wait = WebDriverWait(driver, 10)
            wait.until(EC.visibility_of_element_located((By.CLASS_NAME, "vehicle-availability")))
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(5)
            jsoup = BeautifulSoup(driver.page_source)
            cars =  jsoup.find_all('div', attrs={'class': 'row avilablecar available-car-box'})
            linfo = jsoup.find('div', attrs={'class':'location-info'})
            linfo = linfo.text.strip() if linfo is not None else None

            try:
                extraCar = jsoup.find('div', attrs={'class': 'featuredcar featured-car-box'})
                className = extraCar.find('h3').text.strip()
                vehicleName = extraCar.find('p', attrs={'class':'featurecartxt'})
                vehicleName = vehicleName.text if vehicleName is not None else None
                payLaterAmount = extraCar.find('p', attrs={'class':'payamntp'})
                payLaterAmount = payLaterAmount.text.strip() if payLaterAmount is not None else None
                Pay_Now_Amount = extraCar.find('p', attrs={'class':'payamntr'})
                Pay_Now_Amount = Pay_Now_Amount.text.strip() if Pay_Now_Amount is not None else None
                if payLaterAmount is not None:
                    data = [datetime.today().strftime('%m/%d/%Y'), start_date, end_date, row["Location"], row["Airport name"],
                     linfo,row["Code"], className, vehicleName, payLaterAmount, Pay_Now_Amount, "Budget"]
                    carData.append(data)
            except Exception as error:
                print(error)
            print(len(cars))
            for car in cars:
                try:
                    className = car.find('h3').text.strip()
                    vehicleName = car.find('p', attrs={'class': re.compile('featurecartxt')})
                    vehicleName = vehicleName.text.strip() if vehicleName is not None else None
                    Pay_Now_Amount = car.find('div', attrs={'class': re.compile('paynow')})
                    Pay_Now_Amount = (Pay_Now_Amount.find('p').text.strip() if Pay_Now_Amount.find('p') is not None else None)if Pay_Now_Amount is not None else None
                    payLaterAmount = car.find('div', attrs={'class': re.compile('payatcntr')})
                    payLaterAmount = (payLaterAmount.find('p').text.strip() if payLaterAmount.find('p') is not None else None) if payLaterAmount is not None else None
                    if payLaterAmount is not None:
                        data = [datetime.today().strftime('%m/%d/%Y'), start_date, end_date, row["Location"], row["Airport name"], linfo,
                         row["Code"], className, vehicleName, payLaterAmount, Pay_Now_Amount, "Budget"]
                        print(data)
                        carData.append(data)
                except Exception as e:
                    print(e)
            count += 1

        except Exception as e:
            driver.save_screenshot(dir+'\\'+row['Code'] + datetime.today().strftime('%d-%m-%Y') + ".png")
            if check_count == 2:
                break
            check_count += 1
            check_days.append(k)
            print(e, row)
            print(e)
    driver.close()
    if len(carData) != 0:
        car_data[row['Code']] = carData
        return car_data
