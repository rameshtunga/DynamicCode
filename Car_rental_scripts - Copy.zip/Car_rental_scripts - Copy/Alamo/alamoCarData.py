# -*- coding:utf-8 -*-
from datetime import datetime
from datetime import timedelta
import pandas as pd
import time
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from bs4 import BeautifulSoup
from tabulate import tabulate
import re
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException


import warnings
warnings.simplefilter(action='ignore')

startTime = time.time()

def get_alamo_car_data(row, car_data):
    dir = os.getcwd() +'\\'+ datetime.today().strftime('%d-%m-%Y')
    if not os.path.isdir(dir):
        os.mkdir(dir)
    browser = webdriver.Firefox()
    browser.maximize_window()
    carData = []
    count = 0
    check_count = 0
    check_days = [[15, 17], [15, 22]]
    for k in check_days:
        try:
            start_date = (datetime.now() + timedelta(days=k[0])).strftime('%m/%d/%Y')
            end_date = (datetime.now() + timedelta(days=k[1])).strftime('%m/%d/%Y')
            print(start_date,end_date)
            browser.get('https://www.alamo.com/en_US/car-rental/home.html') #https://www.alamo.com/en_US/car-rental/reservation/aboutYourTrip.html
            time.sleep(5)

            try:
                browser.find_element_by_xpath('/html/body/div[3]/div/p/a[1]/img').click()
            except :
                pass

            #LOCATION
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpLocation_searchCriteria"]').clear()
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpLocation_searchCriteria"]').send_keys(row['Code'])

            #POPUP
            try:
                browser.find_element_by_xpath('/html/body/div[3]/div/p/a[1]/img').click()
            except:
                pass

            time.sleep(3)

            #LOCATION
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpLocation_searchCriteria"]').send_keys(Keys.ARROW_DOWN)
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpLocation_searchCriteria"]').send_keys(Keys.RETURN)
            time.sleep(2)
            browser.find_element_by_css_selector('#_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_countryOfResidenceResident').click()
            time.sleep(3)

            #POPUP
            try:
                browser.find_element_by_xpath('/html/body/div[3]/div/p/a[1]/img').click()
            except:
                pass

            #PICKUP_DATE
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpDateTime_date"]').clear()
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpDateTime_date"]').send_keys(start_date)
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_pickUpDateTime_date"]').send_keys(Keys.RETURN)

            #RETURN_DATE
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_dropOffDateTime_date"]').clear()
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_dropOffDateTime_date"]').send_keys(end_date)
            browser.find_element_by_xpath('//*[@id="_content_alamo_en_US_car_rental_home_jcr_content_reservationStart_dropOffDateTime_date"]').send_keys(Keys.RETURN)
            time.sleep(5)

            #SCROLL_DOWN
            browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(3)

            #POPUP
            try:
                browser.find_element_by_xpath('/html/body/div[3]/div/p/a[1]/img').click()
            except:
                pass

            time.sleep(3)

            #SUBMIT_BUTTON
            try:
                browser.find_element_by_css_selector('button.a-btn:nth-child(2)').click()
                time.sleep(5)
            except:
                pass
            #SOLD_OUT POPUP
            try:

                if 'sold out'.lower() in browser.page_source.lower():
                    print('sold_out')

                    browser.save_screenshot(dir+'\\'+row['Code'] + datetime.today().strftime('%d-%m-%Y') + ".png")
                    continue

            except:
                pass

            #POPUP
            try:
                browser.find_element_by_xpath('/html/body/div[3]/div/p/a[1]/img').click()
            except :
                pass

            print(browser.current_url)

            time.sleep(5)
            #PAGE_SOURCE
            jsoup = BeautifulSoup(browser.page_source)
            lis = jsoup.find('section',attrs={'class':'blockPrimary'}).find('ul', attrs={'class': 'carList'}).find_all('li',attrs={'class':re.compile('\w*')})

            for li in lis:
                # print(li)
                car_class = li.find('div', attrs={'class':'carDetails'}).find('h2')
                print(car_class.text)
                car_name = li.find('div', attrs={'class':'vehiclesSimilar'}).find('span')
                print(car_name.text)

                per_day_now = li.find('div',attrs = {'class':'priceInfoDetails'})
                per_day_now = per_day_now.find('div', attrs={'class':'largePayment'})if per_day_now is not None else None

                per_day_now = per_day_now.find_all('p')[0] if per_day_now is not None else None
                # print(per_day_now.text)

                per_day_now = re.search('\$[0-9\.]+', per_day_now.text) if per_day_now is not None else None
                per_day_now = per_day_now.group(0) if per_day_now is not None else None
                print(per_day_now)


                per_day_now_unit = li.find('div',attrs = {'class':'priceInfoDetails'})
                per_day_now_unit = per_day_now_unit.find_all('p')[0] if per_day_now_unit is not None else None
                per_day_now_unit = per_day_now_unit.find_all('span')[1] if per_day_now_unit is not None else None
                per_day_now_unit = re.search('[ A-Za-z]+', per_day_now_unit.text) if per_day_now is not None else None
                per_day_now_unit = per_day_now_unit.group(0) if per_day_now_unit is not None else None
                print(per_day_now_unit)




                pay_now_total = li.find('div', attrs={'class': 'priceInfoDetails'})
                # print('++++++++++++++++++++++++++++++++')
                pay_now_total = pay_now_total.find('div', attrs={'class': 'largePayment'}) if pay_now_total is not None else None
                # print('-------------------------------')
                pay_now_total = pay_now_total.find_all('p')[1] if pay_now_total is not None else None
                pay_now_total_unit = re.search('[A-Za-z]+', pay_now_total.text) if pay_now_total is not None else None
                pay_now_total_unit = pay_now_total_unit.group(0) if pay_now_total_unit is not None else None
                print(pay_now_total_unit)
                pay_now_total = re.search('\$[0-9\.]+', pay_now_total.text) if pay_now_total is not None else None
                pay_now_total = pay_now_total.group(0) if pay_now_total is not None else None
                print(pay_now_total)



                print('-----------------------------------------------------------------------------------------------')
                per_day_later = li.find('div', attrs={'class': 'priceInfoDetails'})
                per_day_later = per_day_later.find('div', attrs={'class':re.compile('smallPayment|smallPaymentOnly')}) if per_day_later is not None else None
                per_day_later = per_day_later.find_all('p')[0] if per_day_later is not None else None
                # per_day_later_unit = re.search('[ A-Za-z]+',per_day_later.text) if per_day_later is not None else None
                # per_day_later_unit = per_day_later_unit.group(1) if per_day_later_unit is not None else None
                # print(per_day_later_unit)
                # per_day_later_unit = per_day_later_unit if per_day_later_unit is not None else None
                per_day_later = re.search('\$[0-9\.]+',per_day_later.text) if per_day_later is not None else None
                per_day_later = per_day_later.group(0) if per_day_later is not None else None
                print(per_day_later)

                per_day_later_unit = li.find('div', attrs={'class': 'priceInfoDetails'})
                per_day_later_unit = per_day_later_unit.find('div', attrs={'class': re.compile('smallPayment|smallPaymentOnly')}) if per_day_later_unit is not None else None
                per_day_later_unit = per_day_later_unit.find_all('p')[0] if per_day_later_unit is not None else None
                per_day_later_unit = per_day_later_unit.find_all('span')[1] if per_day_later_unit is not None else None
                per_day_later_unit = re.search('[ A-Za-z]+',per_day_later_unit.text) if per_day_later_unit is not None else None
                per_day_later_unit = per_day_later_unit.group(0) if per_day_later_unit is not None else None
                print(per_day_later_unit)


                pay_later_total = li.find('div',attrs = {'class':'priceInfoDetails'})
                pay_later_total = pay_later_total.find('div', attrs={'class':re.compile('smallPayment|smallPaymentOnly')}) if pay_later_total is not None else None
                pay_later_total = pay_later_total.find_all('p')[1] if pay_later_total is not None else None
                pay_later_total_unit = re.search('[A-Za-z]+', pay_later_total.text) if pay_later_total is not None else None
                pay_later_total_unit = pay_later_total_unit.group(0) if pay_later_total_unit is not None else None
                print(pay_later_total_unit)
                pay_later_total = re.search('\$[0-9\.]+', pay_later_total.text) if pay_later_total is not None else None
                pay_later_total = pay_later_total.group(0) if pay_later_total is not None else None
                print(pay_later_total)
                print('-'.center(100,'-'))
                if pay_later_total is not None:
                    data = [datetime.now().strftime('%m/%d/%Y'), start_date,end_date, row['Location'], row['Airport name'], row['Airport name'], row['Code'], car_class.text, car_name.text,per_day_now,per_day_now_unit,pay_now_total,pay_now_total_unit,per_day_later,per_day_later_unit, pay_later_total,pay_later_total_unit,'Alamo']
                    print(data)
                    carData.append(data)
            count += 1
        except Exception as e:
            browser.save_screenshot(dir+'\\'+row['Code'] + datetime.today().strftime('%d-%m-%Y') + ".png")
            if check_count == 2:
                break
            check_count += 1
            check_days.append(k)
            print(e, row)

    browser.close()
    if len(carData) != 0:
        car_data[row['Code']] = carData
        return car_data
