import pandas as pd
import xlrd
import xlwt

book = xlwt.Workbook()
from pandas_datareader import data, wb
from ExcelFormat import cellStyle, customizedCell, highlightColumn
import os

Location = os.getcwd()+'\\output\\19-09-2018'
EX = pd.ExcelFile(Location+'\\carRentalData.xlsx')
df =  df_sheets= pd.read_excel(EX, 'Consolidated-Mario')
# df = pd.ExcelFile(Location+'\\carRentalData.xls')
#
df = df.pivot_table('Rate Per Day', index=['Days','Company'], aggfunc='mean').unstack()
excel_file = 'zzzzz.xlsx'
# sheet_name = 'Sheet1'
#
# writer = pd.ExcelWriter(excel_file, engine='xlsxwriter')
# df.to_excel(writer, sheet_name=sheet_name)
cellProperties_headers = {'fontSize': 9,
                  'fontStyle': 'Calibri',
                  'fontBold': True,
                  'cellBorderBottom': 'thin',
                  'wrapText': True,
                  'text_horizontal_alignment': 'left',
                  'text_vertical_alignment':'top'
                  }

cellProperties_content = {'fontSize': 9,
                  'fontStyle': 'Calibri',

                  }
import math
headerStyle = cellStyle(cellProperties = cellProperties_headers)
contentStyle = cellStyle(cellProperties=cellProperties_content)
highLightProperties = highlightColumn(cellProperties = cellProperties_content, color = 'gray25')

df_sheets = pd.ExcelFile(Location+'\\carRentalData.xlsx')
with pd.ExcelWriter(excel_file, engine='xlsxwriter') as writer:
    df.to_excel(writer, sheet_name='Graph')
    workbook = writer.book
    for sheetName in df.sheet_names:

        sheet = book.add_sheet(sheetName)
        df1 = pd.read_excel(df, sheetName)
        for col, value in enumerate(df1.columns.values.tolist()):
            customizedCell(sheet, 0, col, value, style=headerStyle)

        for row, value in enumerate(df1.values.tolist()):
            for col, val in enumerate(value):
                if isinstance(val, float):
                    if math.isnan(val):
                        val = ' '
                if sheetName == 'Consolidated-Mario':
                    if col in [3, 10]:
                        customizedCell(sheet, row + 1, col, val, style=highLightProperties)
                    else:
                        customizedCell(sheet, row + 1, col, val, style=contentStyle)
                else:
                    customizedCell(sheet, row + 1, col, val, style=contentStyle)


    sname = 'Graph'

    worksheet = writer.sheets['Graph']
    chart = workbook.add_chart({'type': 'column'})
    colors = ['#E41A1C', '#377EB8', '#4DAF4A', '#984EA3', '#FF7F00']

    # Configure the series of the chart from the dataframe data.
    row_count = 5
    column_count = 9
    print('row_count = ', row_count)
    print('column_count = ', column_count)
    i = 0
    for col_num in range(1, row_count - 2):
        chart.add_series({
            'name': [sname, 2 + col_num, 0],
            'categories': [sname, 1, 1, 1, column_count - 1],
            'values': [sname, col_num + 2, 1, col_num + 2, column_count - 1],
            'fill': {'color': colors[i]},
            'overlap': -10,
        })
        i += 1
    chart.set_x_axis({'name': 'Companies'})
    chart.set_y_axis({'name': 'Price', 'major_gridlines': {'visible': False}})

    # Insert the chart into the worksheet.
    worksheet.insert_chart('K2', chart)

    # Close the Pandas Excel writer and output the Excel file.
    # writer.save()
    # for sheetName in df_sheets.sheet_names:
    #     sheet = book.add_sheet(sheetName)
    #     print(sheetName)


# with pd.ExcelWriter(Location+'\\consolidate.xls', engine='xlsxwriter') as writer:
#     for sheetName in df.sheet_names:
#         sheet = book.add_sheet(sheetName)
#         df1 = pd.read_excel(df, sheetName)


# book = xlrd.open_workbook(excel_file)
# sheet = book.sheet_by_name(sheet_name)
#
# # Access the XlsxWriter workbook and worksheet objects from the dataframe.
# workbook  = writer.book
# worksheet = writer.sheets[sheet_name]
#
# chart = workbook.add_chart({'type': 'column'})
# colors = ['#E41A1C', '#377EB8', '#4DAF4A', '#984EA3', '#FF7F00']
#
# # Configure the series of the chart from the dataframe data.
# row_count = sheet.nrows
# column_count = sheet.ncols
# print('row_count = ', row_count)
# print('column_count = ', column_count)
# i = 0
# for col_num in range(1, row_count-2):
#     chart.add_series({
#         'name':       ['Sheet1', 2+col_num, 0],
#         'categories': ['Sheet1', 1,1,1,column_count-1],
#         'values':     ['Sheet1', col_num+2, 1, col_num+2, column_count-1],
#         'fill':       {'color':  colors[i]},
#         'overlap':    -10,
#     })
#     i+=1
#
# # for row in range(3, row_count):
# #     print(sheet.cell_value(row, 0))
# #     sheet.write(row_count+row, 0, 'Round of'+str(sheet.cell_value(row, 0)))
# #     for col in range(1, column_count):
# #         sheet.write(row_count + row, column_count+col, sheet.cell_value(row, col))
#
#         # print(sheet.cell_value(row, col))
# # Configure the chart axes.
# chart.set_x_axis({'name': 'Companies'})
# chart.set_y_axis({'name': 'Farms', 'major_gridlines': {'visible': False}})
#
# # Insert the chart into the worksheet.
# worksheet.insert_chart('K2', chart)
#
#
# # Close the Pandas Excel writer and output the Excel file.
# writer.save()