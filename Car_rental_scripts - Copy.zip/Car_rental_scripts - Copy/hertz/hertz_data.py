"""
Purpose     : Extract data from comparefirst
        #####################     Change log   ###############################
        ##------------------------------------------------------------------##
        ##  Author              ##Date                ##Current Version     ##
        ##------------------------------------------------------------------##
        ## Moody's Analytics    ##11th July, 2018     ##V1.0                ##
        ##------------------------------------------------------------------##
        ######################################################################
        Date              Version     Author      Description
        11th July, 2018   v 1.0       Sairam      Data Extraction
"""


from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time
from bs4 import BeautifulSoup
from datetime import datetime
from datetime import timedelta
import os

def get_hertz_car_data(row, car_data):
    dir = os.getcwd() + '\\' + datetime.today().strftime('%d-%m-%Y')
    if not os.path.isdir(dir):
        os.mkdir(dir)
    carData = []
    count = 0
    check_count = 0
    driver = webdriver.Firefox()
    check_days = [[15, 17], [15, 22]]
    for k in check_days:
        try:
            print(row)
            START_DATE = (datetime.now() + timedelta(days=k[0])).strftime('%m/%d/%Y')
            END_DATE = (datetime.now() + timedelta(days=k[1])).strftime('%m/%d/%Y')
            start_date = (datetime.now() + timedelta(days=k[0])).strftime('%B %d,%Y')
            end_date = (datetime.now() + timedelta(days=k[1])).strftime('%B %d,%Y')
            start_month = start_date.split()[0]
            start_day = str(int(start_date.split()[1].split(',')[0]))
            end_month = end_date.split()[0]
            end_day = str(int(end_date.split()[1].split(',')[0]))
            driver.delete_all_cookies()

            driver.get('https://www.hertz.com/rentacar/rental-car-deals/asia-usca-30dollarsoff?icid_source=enUS&icid_medium=hero_banner_1&icid_campaign=usca_30dollarsoff')
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="pickup-location"]'))
            ).clear()
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="pickup-location"]'))
            ).send_keys(row['Code'])
            time.sleep(3)

            driver.find_element_by_xpath('//*[@id="pickup-location"]').send_keys(Keys.RETURN)
            # driver.find_element_by_tag_name('body').click()


            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="pickup-date-box"]/div[2]/div[1]'))
            ).click()

            ele = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'calendar'))
            )
            for k in driver.find_elements_by_class_name('wrapper'):
                month = k.find_element_by_tag_name('h1').text
                if start_month.lower() in month.lower():
                    for j in k.find_elements_by_tag_name('td'):
                        if j.text.strip() == start_day.strip():
                            j.click()
                            break

            driver.find_element_by_tag_name('body')
            time.sleep(3)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="dropoff-date-box"]/div[2]/div[1]'))
            ).click()
            print('---------------------------------------------------------------------------------')
            for k in driver.find_elements_by_class_name('wrapper'):
                month = k.find_element_by_tag_name('h1').text
                if end_month.lower() in month.lower():
                    for j in k.find_elements_by_tag_name('td'):
                        if j.text.strip() == end_day.strip():
                            j.click()
                            break
            driver.find_element_by_xpath('//*[@id="pickup-time"]/select/option[25]').click()
            driver.find_element_by_xpath('//*[@id="dropoff-time"]/select/option[25]').click()
            driver.find_element_by_xpath('//*[@id="ageSelector"]/option[8]').click()
            try:
                driver.find_element_by_xpath('//*[@id="discounts"]').click()
            except Exception as e:
                print(e)

            driver.find_element_by_xpath('//*[@id="res-submit-btns"]/div/div/div[2]/button').click()
            try:
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "ok-btn"))
                ).click()
            except Exception as error:
                print(error)

            div = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.ID, "vehicles-list"))
            )

            jsoup = BeautifulSoup(driver.page_source)
            content = jsoup.find('div', attrs={'id':'itinerary-content'})
            for k in content.find_all('label'):
                k.decompose()
            location = content.find('div', attrs={'class':'itn-location-container'})
            # if location.find('label') is not None:
            #     location.find('label').decompose()
            location = location.text
            pickupDate = content.find('div', attrs={'class':'itn-pickup-time divider'})
            if pickupDate is not None:
                pickupDate = pickupDate.text
            returnDate = content.find('div', attrs={'class':'itn-return-time divider'})
            if returnDate is not None:
                returnDate = returnDate.text
            vehicles = div.find_elements_by_class_name('vehicle')
            for id in range(0, len(vehicles)):
                vehicleName = vehicles[id].find_element_by_tag_name('h1').text.strip()
                VehicleGroupLevel = vehicles[id].find_element_by_class_name('vehicle-type').text.strip()
                for button in vehicles[id].find_elements_by_tag_name('button'):
                    print('Id = ',id)
                    try:
                        time.sleep(3)
                        if 'Rate 1' in button.text:
                            button.click()
                            time.sleep(3)
                            print(driver.current_url)
                            if driver.current_url == 'https://www.hertz.com/rentacar/reservation/#extras':
                                ele = WebDriverWait(driver, 30).until(
                                    EC.presence_of_element_located((By.XPATH, '//*[@id="rd-pay-later"]/div/div/div[4]/ul/li/div[2]'))
                                )
                                amount = ele.text if ele is not None else None
                                # print(vehicleName ,'==', ele.text)
                                if amount is not None:
                                    data = [datetime.now().strftime('%m/%d/%Y'), START_DATE, END_DATE, row['Location'], row['Airport name'],location, row['Code'], VehicleGroupLevel, vehicleName,amount, 'Hertz']
                                    print(data)
                                    # data = [pickupDate, returnDate, location, vehicleName, amount]
                                    carData.append(data)
                                break
                    except Exception as e:
                        print(e)
                        pass
                time.sleep(3)
                driver.get('https://www.hertz.com/rentacar/reservation/#vehicles')

                div = WebDriverWait(driver, 30).until(
                    EC.presence_of_element_located((By.ID, "vehicles-list"))
                )
                vehicles = div.find_elements_by_class_name('vehicle')
                # break
            count += 1


        except Exception as e:
            driver.save_screenshot(dir+'\\'+row['Code'] + datetime.today().strftime('%d-%m-%Y') + ".png")
            if check_count == 2:
                break
            check_count += 1
            check_days.append(k)
            print(e, row)
        # break
    driver.close()
    if len(carData) != 0:
        car_data[row['Code']] = carData
        return car_data




