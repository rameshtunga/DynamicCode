import pandas as pd
import re

from datetime import datetime
df = pd.ExcelFile('D:\\completedTasks\\Car_rental_scripts\\output\\23-08-2018\\carRentalData.xlsx')
DF = pd.read_excel(df, 'final_result')


def findDays(x):
    date_format = "%m/%d/%Y"
    a = datetime.strptime(x[0], date_format)
    b = datetime.strptime(x[1], date_format)
    delta = b - a
    return delta.days
def payPerDay(x):
    return round((x[1]/int(x[0])), 2)

DF['payLaterTotalAmount'] = DF['payLaterTotalAmount'].apply(lambda x:float(re.sub('[^0-9\.]', '',x)))
DF['Days'] = DF[['pickup_date', 'return_date']].apply(findDays, axis = 1)
print(DF['Days'])
DF['Rate Per Day'] = DF[['Days', 'payLaterTotalAmount']].apply(payPerDay, axis = 1)
print(DF[['Days', 'Rate Per Day']])
