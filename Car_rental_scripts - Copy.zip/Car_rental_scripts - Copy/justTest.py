import articleDateExtractor
d = articleDateExtractor.extractArticlePublishedDate("https://timesofoman.com/article/454726/Business/Economy/Omani-Turkish-businessmen-discuss-trade-investment")
print (d)